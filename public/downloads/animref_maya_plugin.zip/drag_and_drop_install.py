"""
AnimationReference.org Studio Plugin for Autodesk Maya — Standalone Drag & Drop Installer.

Usage:
    Unzip animref_maya_plugin.zip, then drag and drop drag_and_drop_install.py
    (or drag_and_drop_install.mel) directly into the Autodesk Maya viewport.

Supports Maya 2020–2026 (Python 3, PySide2 & PySide6) on Windows, macOS, and Linux.
"""

from __future__ import absolute_import, division, print_function

import os
import shutil
import sys


def _get_maya_scripts_dir():
    import maya.cmds as cmds

    user_scripts = cmds.internalVar(userScriptDir=True) or ""
    if user_scripts:
        shared_scripts = os.path.normpath(os.path.join(user_scripts, "..", "..", "scripts"))
        if os.path.isdir(shared_scripts):
            return shared_scripts
        return os.path.normpath(user_scripts)
    return os.path.normpath(os.path.join(os.path.expanduser("~"), "Documents", "maya", "scripts"))


def _add_single_launcher_button(dest_pkg):
    import maya.cmds as cmds

    if not cmds or not hasattr(cmds, "shelfTabLayout"):
        return
    try:
        target_shelf = cmds.shelfTabLayout("ShelfLayout", query=True, selectTab=True) or "Custom"
        existing = cmds.shelfLayout(target_shelf, query=True, childArray=True) or []
        for btn in existing:
            try:
                if cmds.objectTypeUI(btn, isType="shelfButton") and cmds.shelfButton(btn, query=True, label=True) == "AnimRef":
                    cmds.deleteUI(btn)
            except Exception:
                pass

        cmd = (
            "import os, sys, maya.cmds as cmds\n"
            "vs = cmds.internalVar(userScriptDir=True) if cmds else ''\n"
            "cands = [\n"
            "    os.path.normpath(os.path.join(vs, '..', '..', 'scripts', 'AnimRef_Studio')),\n"
            "    os.path.normpath(os.path.join(vs, 'AnimRef_Studio')),\n"
            "    os.path.normpath(os.path.join(os.path.expanduser('~'), 'OneDrive', 'Documents', 'maya', 'scripts', 'AnimRef_Studio')),\n"
            "    os.path.normpath(os.path.join(os.path.expanduser('~'), 'Documents', 'maya', 'scripts', 'AnimRef_Studio')),\n"
            "]\n"
            "pkg = next((c for c in cands if os.path.isdir(c)), cands[0])\n"
            "if pkg not in sys.path: sys.path.insert(0, pkg)\n"
            "for m in [k for k in list(sys.modules) if 'animref' in k.lower()]: sys.modules.pop(m, None)\n"
            "import animref_launcher\n"
            "animref_launcher.launch(dock=False, force_new=True)\n"
        )
        icon_path = os.path.join(dest_pkg, "animref_icon.png")
        icon = icon_path if os.path.isfile(icon_path) else "playblast.png"
        cmds.shelfButton(
            parent=target_shelf,
            image=icon,
            label="AnimRef",
            imageOverlayLabel="AnimRef",
            overlayLabelColor=(0.95, 0.95, 0.98),
            overlayLabelBackColor=(0.48, 0.23, 0.93, 0.85),
            command=cmd,
            sourceType="python",
            annotation="Open AnimationReference.org Studio Window",
        )
    except Exception as exc:
        print("[AnimRef] Shelf button skipped:", exc)


def install(installer_dir=None):
    import maya.cmds as cmds

    if not installer_dir:
        installer_dir = os.path.dirname(os.path.abspath(__file__))

    src_pkg = os.path.join(installer_dir, "AnimRef_Studio")
    if not os.path.isdir(src_pkg) or not os.path.isfile(os.path.join(src_pkg, "animref_launcher.py")):
        cmds.confirmDialog(
            title="AnimationReference.org Installer",
            message=(
                "Could not locate the AnimRef_Studio folder next to drag_and_drop_install.py.\n\n"
                "Please unzip the full animref_maya_plugin.zip archive before dragging the installer into Maya."
            ),
            button=["OK"],
            icon="critical",
        )
        return False

    scripts_dir = _get_maya_scripts_dir()
    dest_pkg = os.path.join(scripts_dir, "AnimRef_Studio")

    os.makedirs(scripts_dir, exist_ok=True)
    if os.path.isdir(dest_pkg):
        shutil.rmtree(dest_pkg, ignore_errors=True)
    shutil.copytree(
        src_pkg,
        dest_pkg,
        ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.pyo", ".DS_Store"),
    )

    if dest_pkg not in sys.path:
        sys.path.insert(0, dest_pkg)

    for mod_name in list(sys.modules.keys()):
        if "animref" in mod_name.lower():
            del sys.modules[mod_name]

    _add_single_launcher_button(dest_pkg)

    import animref_launcher
    animref_launcher.launch(dock=False, force_new=True)

    cmds.inViewMessage(
        amg='<span style="color:#a78bfa; font-weight:bold;">AnimationReference.org Studio installed!</span>',
        pos="midCenter",
        fade=True,
        fst=350,
        fad=500,
    )
    print("[AnimRef] Installed standalone plugin to:", dest_pkg)
    return True


def onMayaDroppedPythonFile(*args, **kwargs):
    """Entry point invoked automatically by Autodesk Maya on drag-and-drop."""
    install()


if __name__ == "__main__":
    install()
