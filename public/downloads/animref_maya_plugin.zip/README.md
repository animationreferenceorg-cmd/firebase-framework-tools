# AnimationReference.org Studio Plugin for Autodesk Maya

## Quick Install (30 seconds)
1. Unzip nimref_maya_plugin.zip.
2. Drag and drop drag_and_drop_install.mel (or drag_and_drop_install.py) straight into your Maya 3D viewport.
3. AnimRef Studio docks automatically on the right side of Maya and opens your Saved References.
4. Click **Sign In** once to sync your AnimationReference.org Moodboards, Saved References, Uploaded clips, and automatic updates.

Supports Maya 2020-2026 (Python 3, PySide2 & PySide6) on Windows, macOS, and Linux.
