# AnimationReference.org Studio Plugin for Autodesk Maya

## Quick 3-Step Install (Maya 2020 - 2026)
1. Unzip this archive anywhere on your computer.
2. Drag and drop drag_and_drop_install.py (or drag_and_drop_install.mel) directly into your Maya viewport.
3. Click Sign In via Browser to sync your AnimationReference.org Moodboards, Uploaded references, and automatic updates.

Support & Docs: https://animationreference.org/tools
